import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Header from "@/components/layout/Header";
import PageContainer from "@/components/layout/PageContainer";
import StatsSection from "@/components/home/StatsSection";
import VehicleTabs from "@/components/home/VehicleTabs";
import AddVehicleDialog from "@/components/home/AddVehicleDialog";
import { useToast } from "@/components/ui/use-toast";

const HomePage = () => {
  const [vehicles, setVehicles] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const savedVehicles = localStorage.getItem("vehicles");
    if (savedVehicles) {
      setVehicles(JSON.parse(savedVehicles));
    } else {
      const sampleVehicles = [
        { id: "v1", name: "Truck Alpha", regNumber: "SMPL-01-TR-001", type: "Heavy Truck", status: "active", location: "Main Depot", fuelLevel: 80, lastMaintenance: "2025-03-10" },
        { id: "v2", name: "Van Beta", regNumber: "SMPL-01-VN-002", type: "Delivery Van", status: "maintenance", location: "Service Garage", fuelLevel: 45, lastMaintenance: "2025-05-01" },
      ];
      setVehicles(sampleVehicles);
      localStorage.setItem("vehicles", JSON.stringify(sampleVehicles));
      toast({
        title: "Sample Data Loaded",
        description: "Showing sample vehicles. Add your own to get started!",
        duration: 5000,
      });
    }
  }, [toast]);

  const handleVehicleSelect = (vehicle) => {
    toast({
      title: "Vehicle Selected",
      description: `You selected ${vehicle.name} (${vehicle.regNumber})`,
    });
  };

  const handleAddVehicleSubmit = (newVehicleData) => {
    const newVehicle = {
      id: `v${vehicles.length + 1}-${Date.now()}`,
      ...newVehicleData,
      location: "Not specified", 
      lastMaintenance: new Date().toISOString().split('T')[0]
    };
    const updatedVehicles = [...vehicles, newVehicle];
    setVehicles(updatedVehicles);
    localStorage.setItem("vehicles", JSON.stringify(updatedVehicles));
    toast({
      title: "Vehicle Added",
      description: `${newVehicle.name} has been added to your fleet.`,
    });
    setIsAddDialogOpen(false);
  };

  return (
    <>
      <Header title="Fleet Management" />
      <PageContainer>
        <StatsSection vehicles={vehicles} tripsCount={localStorage.getItem("trips") ? JSON.parse(localStorage.getItem("trips")).filter(t => t.status === 'scheduled').length : 0} />

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <VehicleTabs 
            vehicles={vehicles}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onVehicleSelect={handleVehicleSelect}
            onAddVehicleClick={() => setIsAddDialogOpen(true)}
          />
        </motion.div>

        <AddVehicleDialog 
          isOpen={isAddDialogOpen}
          onOpenChange={setIsAddDialogOpen}
          onAddVehicle={handleAddVehicleSubmit}
        />
      </PageContainer>
    </>
  );
};

export default HomePage;
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { LogIn, User, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from "@/components/ui/use-toast";

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const { toast } = useToast();

  const predefinedUsers = {
    leader: { username: 'leader', password: 'password123', role: 'leader', name: 'Main Leader' },
    teammember: { username: 'member', password: 'password123', role: 'teammember', name: 'Team Member One' },
  };

  const handleLogin = (e) => {
    e.preventDefault();
    setError('');

    const foundUser = Object.values(predefinedUsers).find(
      (u) => u.username === username && u.password === password
    );

    if (foundUser) {
      login({ id: foundUser.username, name: foundUser.name, role: foundUser.role });
      toast({
        title: "Login Successful",
        description: `Welcome back, ${foundUser.name}!`,
      });
    } else {
      setError('Invalid username or password.');
      toast({
        title: "Login Failed",
        description: "Invalid username or password. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-700 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="w-full max-w-md shadow-2xl bg-slate-800 border-slate-700 text-gray-100">
          <CardHeader className="text-center">
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="mx-auto mb-4"
            >
              <LogIn className="h-16 w-16 text-primary" />
            </motion.div>
            <CardTitle className="text-3xl font-bold">Transport Manager Login</CardTitle>
            <CardDescription className="text-gray-400">
              Access your transport business dashboard.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username" className="flex items-center text-gray-300">
                  <User className="h-4 w-4 mr-2" /> Username
                </Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="flex items-center text-gray-300">
                  <Key className="h-4 w-4 mr-2" /> Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary"
                />
              </div>
              {error && <p className="text-sm text-red-400">{error}</p>}
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-3">
                <LogIn className="h-5 w-5 mr-2" /> Sign In
              </Button>
            </form>
          </CardContent>
          <CardFooter className="text-center text-xs text-gray-500">
            <p>
              Demo users: leader/password123 OR member/password123
            </p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default LoginPage;

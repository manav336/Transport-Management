
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Calendar, Search, Plus, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import PageContainer from "@/components/layout/PageContainer";
import StatCard from "@/components/dashboard/StatCard";
import TripCard from "@/components/trips/TripCard";
import { useToast } from "@/components/ui/use-toast";

const TripsPage = () => {
  const [trips, setTrips] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTrip, setSelectedTrip] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    // Simulating data fetch from localStorage or API
    const savedTrips = localStorage.getItem("trips");
    
    if (savedTrips) {
      setTrips(JSON.parse(savedTrips));
    } else {
      // Sample data
      const sampleTrips = [
        {
          id: "t1",
          title: "Warehouse to Distribution Center",
          origin: "Main Warehouse",
          destination: "Distribution Center A",
          date: "May 25, 2025",
          departureTime: "08:00 AM",
          estimatedArrival: "11:30 AM",
          status: "scheduled",
          vehicle: "Truck 1",
          driver: "John Smith"
        },
        {
          id: "t2",
          title: "Cross-City Delivery",
          origin: "Distribution Center A",
          destination: "Retail Store #5",
          date: "May 25, 2025",
          departureTime: "09:15 AM",
          estimatedArrival: "10:45 AM",
          status: "inProgress",
          vehicle: "Van 1",
          driver: "Sarah Johnson"
        },
        {
          id: "t3",
          title: "Supply Pickup",
          origin: "Supplier HQ",
          destination: "Main Warehouse",
          date: "May 24, 2025",
          departureTime: "02:00 PM",
          estimatedArrival: "04:30 PM",
          status: "completed",
          vehicle: "Truck 2",
          driver: "Michael Brown"
        }
      ];
      
      setTrips(sampleTrips);
      localStorage.setItem("trips", JSON.stringify(sampleTrips));
    }
  }, []);

  const filteredTrips = trips.filter(trip => 
    trip.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    trip.origin.toLowerCase().includes(searchQuery.toLowerCase()) ||
    trip.destination.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleTripSelect = (trip) => {
    setSelectedTrip(trip);
    toast({
      title: "Trip Selected",
      description: `You selected ${trip.title}`,
    });
  };

  const stats = [
    { 
      title: "Total Trips", 
      value: trips.length, 
      icon: <Calendar className="h-6 w-6 text-blue-600" />, 
      color: "bg-blue-100" 
    },
    { 
      title: "Scheduled", 
      value: trips.filter(t => t.status === "scheduled").length, 
      icon: <Clock className="h-6 w-6 text-amber-600" />, 
      color: "bg-amber-100" 
    },
    { 
      title: "In Progress", 
      value: trips.filter(t => t.status === "inProgress").length, 
      icon: <AlertCircle className="h-6 w-6 text-purple-600" />, 
      color: "bg-purple-100" 
    },
    { 
      title: "Completed", 
      value: trips.filter(t => t.status === "completed").length, 
      trend: 15, 
      icon: <CheckCircle className="h-6 w-6 text-green-600" />, 
      color: "bg-green-100" 
    }
  ];

  return (
    <>
      <Header title="Trip Management" />
      <PageContainer>
        <div className="mb-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
          >
            {stats.map((stat, index) => (
              <StatCard 
                key={index}
                title={stat.title}
                value={stat.value}
                trend={stat.trend}
                icon={stat.icon}
                color={stat.color}
              />
            ))}
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="all">All Trips</TabsTrigger>
                <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
                <TabsTrigger value="inProgress">In Progress</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
              </TabsList>
              
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Schedule Trip
              </Button>
            </div>
            
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search trips..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredTrips.length > 0 ? (
                  filteredTrips.map(trip => (
                    <TripCard 
                      key={trip.id} 
                      trip={trip} 
                      onSelect={handleTripSelect}
                    />
                  ))
                ) : (
                  <div className="col-span-full text-center py-10">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                      <Calendar className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-medium">No trips found</h3>
                    <p className="text-muted-foreground mt-1">
                      {searchQuery ? "Try a different search term" : "Schedule your first trip to get started"}
                    </p>
                    <Button className="mt-4">
                      <Plus className="h-4 w-4 mr-2" />
                      Schedule Trip
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
            
            {["scheduled", "inProgress", "completed"].map((status) => (
              <TabsContent key={status} value={status} className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredTrips.filter(t => t.status === status).length > 0 ? (
                    filteredTrips
                      .filter(t => t.status === status)
                      .map(trip => (
                        <TripCard 
                          key={trip.id} 
                          trip={trip} 
                          onSelect={handleTripSelect}
                        />
                      ))
                  ) : (
                    <div className="col-span-full text-center py-10">
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                        <Calendar className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <h3 className="text-lg font-medium">No {status.replace(/([A-Z])/g, ' $1').toLowerCase()} trips</h3>
                      <p className="text-muted-foreground mt-1">
                        {status === "scheduled" ? "Schedule a new trip to see it here" : 
                         status === "inProgress" ? "No trips are currently in progress" :
                         "No trips have been completed yet"}
                      </p>
                      {status === "scheduled" && (
                        <Button className="mt-4">
                          <Plus className="h-4 w-4 mr-2" />
                          Schedule Trip
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </motion.div>
      </PageContainer>
    </>
  );
};

export default TripsPage;

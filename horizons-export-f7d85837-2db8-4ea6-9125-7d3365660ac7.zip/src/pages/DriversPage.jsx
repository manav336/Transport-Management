
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Users, Search, Plus, UserCheck, UserX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import PageContainer from "@/components/layout/PageContainer";
import StatCard from "@/components/dashboard/StatCard";
import DriverCard from "@/components/drivers/DriverCard";
import { useToast } from "@/components/ui/use-toast";

const DriversPage = () => {
  const [drivers, setDrivers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDriver, setSelectedDriver] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    // Simulating data fetch from localStorage or API
    const savedDrivers = localStorage.getItem("drivers");
    
    if (savedDrivers) {
      setDrivers(JSON.parse(savedDrivers));
    } else {
      // Sample data
      const sampleDrivers = [
        {
          id: "d1",
          name: "John Smith",
          licenseNumber: "DL-123456789",
          phone: "+1 234-567-8901",
          joinDate: "Jan 15, 2024",
          status: "available",
          currentLocation: "Warehouse A"
        },
        {
          id: "d2",
          name: "Sarah Johnson",
          licenseNumber: "DL-987654321",
          phone: "+1 987-654-3210",
          joinDate: "Mar 10, 2024",
          status: "on-trip",
          currentLocation: "Route 66"
        },
        {
          id: "d3",
          name: "Michael Brown",
          licenseNumber: "DL-456789123",
          phone: "+1 456-789-1230",
          joinDate: "Feb 5, 2024",
          status: "available",
          currentLocation: "Distribution Center"
        }
      ];
      
      setDrivers(sampleDrivers);
      localStorage.setItem("drivers", JSON.stringify(sampleDrivers));
    }
  }, []);

  const filteredDrivers = drivers.filter(driver => 
    driver.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    driver.licenseNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDriverSelect = (driver) => {
    setSelectedDriver(driver);
    toast({
      title: "Driver Selected",
      description: `You selected ${driver.name}`,
    });
  };

  const stats = [
    { 
      title: "Total Drivers", 
      value: drivers.length, 
      icon: <Users className="h-6 w-6 text-blue-600" />, 
      color: "bg-blue-100" 
    },
    { 
      title: "Available Drivers", 
      value: drivers.filter(d => d.status === "available").length, 
      trend: 10, 
      icon: <UserCheck className="h-6 w-6 text-green-600" />, 
      color: "bg-green-100" 
    },
    { 
      title: "On Trip", 
      value: drivers.filter(d => d.status === "on-trip").length, 
      trend: 5, 
      icon: <UserX className="h-6 w-6 text-amber-600" />, 
      color: "bg-amber-100" 
    }
  ];

  return (
    <>
      <Header title="Driver Management" />
      <PageContainer>
        <div className="mb-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {stats.map((stat, index) => (
              <StatCard 
                key={index}
                title={stat.title}
                value={stat.value}
                trend={stat.trend}
                icon={stat.icon}
                color={stat.color}
              />
            ))}
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="all">All Drivers</TabsTrigger>
                <TabsTrigger value="available">Available</TabsTrigger>
                <TabsTrigger value="on-trip">On Trip</TabsTrigger>
              </TabsList>
              
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Driver
              </Button>
            </div>
            
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search drivers..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDrivers.length > 0 ? (
                  filteredDrivers.map(driver => (
                    <DriverCard 
                      key={driver.id} 
                      driver={driver} 
                      onSelect={handleDriverSelect}
                    />
                  ))
                ) : (
                  <div className="col-span-full text-center py-10">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                      <Users className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-medium">No drivers found</h3>
                    <p className="text-muted-foreground mt-1">
                      {searchQuery ? "Try a different search term" : "Add your first driver to get started"}
                    </p>
                    <Button className="mt-4">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Driver
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="available" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDrivers.filter(d => d.status === "available").length > 0 ? (
                  filteredDrivers
                    .filter(d => d.status === "available")
                    .map(driver => (
                      <DriverCard 
                        key={driver.id} 
                        driver={driver} 
                        onSelect={handleDriverSelect}
                      />
                    ))
                ) : (
                  <div className="col-span-full text-center py-10">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                      <UserCheck className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-medium">No available drivers</h3>
                    <p className="text-muted-foreground mt-1">
                      All your drivers are currently on trips
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="on-trip" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDrivers.filter(d => d.status === "on-trip").length > 0 ? (
                  filteredDrivers
                    .filter(d => d.status === "on-trip")
                    .map(driver => (
                      <DriverCard 
                        key={driver.id} 
                        driver={driver} 
                        onSelect={handleDriverSelect}
                      />
                    ))
                ) : (
                  <div className="col-span-full text-center py-10">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                      <UserX className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-medium">No drivers on trip</h3>
                    <p className="text-muted-foreground mt-1">
                      All your drivers are currently available
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </PageContainer>
    </>
  );
};

export default DriversPage;

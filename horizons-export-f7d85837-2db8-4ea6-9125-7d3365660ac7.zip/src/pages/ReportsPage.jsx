
import React from "react";
import { motion } from "framer-motion";
import { BarChart, PieChart, LineChart, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import PageContainer from "@/components/layout/PageContainer";
import { Separator } from "@/components/ui/separator";

const ReportsPage = () => {
  return (
    <>
      <Header title="Reports & Analytics" />
      <PageContainer>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Tabs defaultValue="overview" className="w-full">
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="vehicles">Vehicles</TabsTrigger>
                <TabsTrigger value="drivers">Drivers</TabsTrigger>
                <TabsTrigger value="trips">Trips</TabsTrigger>
              </TabsList>
              
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>

            <TabsContent value="overview" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium">Fleet Utilization</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80 flex items-center justify-center bg-muted/20 rounded-md">
                      <div className="text-center">
                        <PieChart className="h-10 w-10 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Pie chart visualization will appear here</p>
                      </div>
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Active</p>
                        <p className="text-xl font-bold text-green-600">65%</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Idle</p>
                        <p className="text-xl font-bold text-amber-600">25%</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Maintenance</p>
                        <p className="text-xl font-bold text-red-600">10%</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium">Monthly Trips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80 flex items-center justify-center bg-muted/20 rounded-md">
                      <div className="text-center">
                        <BarChart className="h-10 w-10 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Bar chart visualization will appear here</p>
                      </div>
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Total</p>
                        <p className="text-xl font-bold">125</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Completed</p>
                        <p className="text-xl font-bold text-green-600">112</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Cancelled</p>
                        <p className="text-xl font-bold text-red-600">13</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="md:col-span-2">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium">Fuel Consumption Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80 flex items-center justify-center bg-muted/20 rounded-md">
                      <div className="text-center">
                        <LineChart className="h-10 w-10 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Line chart visualization will appear here</p>
                      </div>
                    </div>
                    <div className="mt-4 grid grid-cols-4 gap-4 text-center">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">This Month</p>
                        <p className="text-xl font-bold">2,450 L</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Last Month</p>
                        <p className="text-xl font-bold">2,380 L</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Avg. Cost</p>
                        <p className="text-xl font-bold">$3.25/L</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Efficiency</p>
                        <p className="text-xl font-bold text-green-600">+2.5%</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-medium mb-4">Key Performance Indicators</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="text-base font-medium mb-2">On-Time Delivery Rate</h4>
                      <div className="flex items-end justify-between">
                        <div>
                          <p className="text-3xl font-bold">94.5%</p>
                          <p className="text-sm text-green-600">+2.3% vs last month</p>
                        </div>
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                          <span className="text-green-600 text-lg font-bold">A+</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="text-base font-medium mb-2">Average Trip Duration</h4>
                      <div className="flex items-end justify-between">
                        <div>
                          <p className="text-3xl font-bold">3.2 hrs</p>
                          <p className="text-sm text-amber-600">+0.5 hrs vs last month</p>
                        </div>
                        <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center">
                          <span className="text-amber-600 text-lg font-bold">B</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="text-base font-medium mb-2">Maintenance Compliance</h4>
                      <div className="flex items-end justify-between">
                        <div>
                          <p className="text-3xl font-bold">98.2%</p>
                          <p className="text-sm text-green-600">+1.1% vs last month</p>
                        </div>
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                          <span className="text-green-600 text-lg font-bold">A</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="vehicles" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Vehicle Performance Report</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-10">
                    <BarChart className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium">Vehicle reports will be displayed here</h3>
                    <p className="text-muted-foreground mt-1 max-w-md mx-auto">
                      Detailed analytics about vehicle performance, maintenance history, and fuel efficiency
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="drivers" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Driver Performance Report</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-10">
                    <BarChart className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium">Driver reports will be displayed here</h3>
                    <p className="text-muted-foreground mt-1 max-w-md mx-auto">
                      Detailed analytics about driver performance, trip history, and safety records
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="trips" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Trip Analysis Report</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-10">
                    <BarChart className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium">Trip reports will be displayed here</h3>
                    <p className="text-muted-foreground mt-1 max-w-md mx-auto">
                      Detailed analytics about trip efficiency, delivery times, and route optimization
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </PageContainer>
    </>
  );
};

export default ReportsPage;

import React from "react";
import { motion } from "framer-motion";
import { User, Bell, Shield, Database, HelpCircle, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import PageContainer from "@/components/layout/PageContainer";
import { useAuth } from "@/contexts/AuthContext";
import ProfileSettings from "@/components/settings/ProfileSettings";
import CompanySettings from "@/components/settings/CompanySettings";
import NotificationSettings from "@/components/settings/NotificationSettings";
import SecuritySettings from "@/components/settings/SecuritySettings";
import HelpSupport from "@/components/settings/HelpSupport";

const settingsTabs = [
  { value: "profile", label: "Profile", icon: User, component: ProfileSettings },
  { value: "company", label: "Company", icon: Database, component: CompanySettings },
  { value: "notifications", label: "Notifications", icon: Bell, component: NotificationSettings },
  { value: "security", label: "Security", icon: Shield, component: SecuritySettings },
  { value: "help", label: "Help & Support", icon: HelpCircle, component: HelpSupport },
];

const SettingsPage = () => {
  const { logout, user } = useAuth();
  const canManageCompanySettings = user?.role === 'leader';

  return (
    <>
      <Header title="Settings" />
      <PageContainer>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-6"
        >
          <Tabs defaultValue="profile" className="w-full">
            <div className="flex flex-col md:flex-row gap-6">
              <TabsList className="flex flex-col space-y-1 md:w-1/4 h-auto bg-slate-800 p-2 rounded-lg border border-slate-700">
                {settingsTabs.map(tab => {
                  if (tab.value === "company" && !canManageCompanySettings) {
                    return null; 
                  }
                  return (
                    <TabsTrigger 
                      key={tab.value}
                      value={tab.value} 
                      className="justify-start px-4 py-3 h-auto data-[state=active]:bg-primary data-[state=active]:text-white text-gray-300 hover:bg-slate-700 w-full rounded-md transition-all"
                    >
                      <tab.icon className="h-5 w-5 mr-3" />
                      {tab.label}
                    </TabsTrigger>
                  );
                })}
                 <Button 
                    variant="ghost" 
                    onClick={logout} 
                    className="justify-start px-4 py-3 h-auto text-red-400 hover:bg-red-500/20 hover:text-red-300 w-full rounded-md transition-all mt-4"
                  >
                    <LogOut className="h-5 w-5 mr-3" />
                    Logout
                  </Button>
              </TabsList>

              <div className="flex-1 md:w-3/4">
                {settingsTabs.map(tab => {
                   if (tab.value === "company" && !canManageCompanySettings) {
                    return null;
                  }
                  const TabComponent = tab.component;
                  return (
                    <TabsContent key={tab.value} value={tab.value} className="mt-0">
                      <Card className="bg-slate-800 border-slate-700 text-gray-100 shadow-xl">
                        <CardHeader>
                          <CardTitle className="text-2xl text-gray-100">{tab.label}</CardTitle>
                          <CardDescription className="text-gray-400">
                            Manage your {tab.label.toLowerCase()} settings.
                          </CardDescription>
                        </CardHeader>
                        <TabComponent />
                      </Card>
                    </TabsContent>
                  );
                })}
              </div>
            </div>
          </Tabs>
        </motion.div>
      </PageContainer>
    </>
  );
};

export default SettingsPage;

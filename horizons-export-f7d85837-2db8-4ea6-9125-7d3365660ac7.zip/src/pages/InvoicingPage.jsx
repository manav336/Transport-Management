import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { FileText, Plus, Search, Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Header from "@/components/layout/Header";
import PageContainer from "@/components/layout/PageContainer";
import InvoiceCard from "@/components/invoicing/InvoiceCard";
import CreateInvoiceDialog from "@/components/invoicing/CreateInvoiceDialog";
import ViewInvoiceDialog from "@/components/invoicing/ViewInvoiceDialog";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";


const InvoicingPage = () => {
  const [invoicesByParty, setInvoicesByParty] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateInvoiceDialogOpen, setIsCreateInvoiceDialogOpen] = useState(false);
  const [isViewInvoiceDialogOpen, setIsViewInvoiceDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [editingInvoice, setEditingInvoice] = useState(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState(null);

  const { toast } = useToast();
  const { user } = useAuth();

  const canEdit = user?.role === 'leader' || user?.role === 'teammember';
  const canDelete = user?.role === 'leader';

  useEffect(() => {
    const savedInvoices = localStorage.getItem("invoicesByParty");
    if (savedInvoices) {
      setInvoicesByParty(JSON.parse(savedInvoices));
    } else {
      const sampleItemDate = new Date(new Date("2025-05-20").setDate(new Date("2025-05-20").getDate() - 2)).toISOString().split('T')[0];
      const sampleInvoicesData = {
        "Client A": [
          { id: "INV-001", customerName: "Client A", vehicleNo: "SMPL-V01", amount: 250.00, invoiceDate: "2025-05-20", status: "Paid", dueDate: "2025-06-01", items: [{itemDate: sampleItemDate, description: "Service 1", quantity: 1, unitPrice: 250}], customerAddress: "123 Main St, Anytown" },
        ],
        "Client B": [
          { id: "INV-002", customerName: "Client B", vehicleNo: "SMPL-V02", amount: 500.00, invoiceDate: "2025-05-22", status: "Pending", dueDate: "2025-06-05", items: [{itemDate: "2025-05-22", description: "Service 2", quantity: 2, unitPrice: 250}], customerAddress: "456 Oak Ave, Otherville" },
        ]
      };
      setInvoicesByParty(sampleInvoicesData);
      localStorage.setItem("invoicesByParty", JSON.stringify(sampleInvoicesData));
    }
  }, []);

  const getAllInvoices = () => {
    return Object.values(invoicesByParty).flat();
  };

  const getNextInvoiceId = () => {
    const allInvoicesList = getAllInvoices();
    if (allInvoicesList.length === 0) {
      return "INV-001";
    }
    const lastInvoiceIdNum = allInvoicesList.reduce((maxId, inv) => {
      const num = parseInt(inv.id.split('-')[1]);
      return num > maxId ? num : maxId;
    }, 0);
    return `INV-${String(lastInvoiceIdNum + 1).padStart(3, '0')}`;
  };
  
  const calculateTotalAmount = (items) => {
    return items.reduce((total, item) => {
      const quantity = parseFloat(item.quantity) || 0;
      const unitPrice = parseFloat(item.unitPrice) || 0;
      return total + (quantity * unitPrice);
    }, 0);
  };

  const handleCreateOrUpdateInvoiceSubmit = (invoiceData) => {
    const totalAmount = calculateTotalAmount(invoiceData.items);
    const partyName = invoiceData.customerName;
    let updatedInvoicesByParty = { ...invoicesByParty };

    if (editingInvoice) { // Update existing invoice
      const invoiceToUpdate = {
        ...editingInvoice,
        ...invoiceData,
        amount: totalAmount,
      };
      
      // Remove from old party if party name changed
      if (editingInvoice.customerName !== partyName) {
        updatedInvoicesByParty[editingInvoice.customerName] = updatedInvoicesByParty[editingInvoice.customerName]?.filter(inv => inv.id !== editingInvoice.id);
        if (updatedInvoicesByParty[editingInvoice.customerName]?.length === 0) {
          delete updatedInvoicesByParty[editingInvoice.customerName];
        }
      }
      
      const partyInvoices = updatedInvoicesByParty[partyName] ? [...updatedInvoicesByParty[partyName]] : [];
      const existingIndex = partyInvoices.findIndex(inv => inv.id === invoiceToUpdate.id);
      if (existingIndex > -1) {
        partyInvoices[existingIndex] = invoiceToUpdate;
      } else {
         partyInvoices.push(invoiceToUpdate); // Add if it was moved to a new party
      }
      updatedInvoicesByParty[partyName] = partyInvoices.sort((a,b) => new Date(b.invoiceDate) - new Date(a.invoiceDate));

      toast({ title: "Invoice Updated", description: `Invoice ${invoiceToUpdate.id} has been updated.` });
      setEditingInvoice(null);

    } else { // Create new invoice
      const newInvoice = {
        id: getNextInvoiceId(),
        ...invoiceData,
        invoiceDate: invoiceData.invoiceDate || new Date().toISOString().split('T')[0],
        amount: totalAmount,
        status: "Pending", 
      };

      const partyInvoices = updatedInvoicesByParty[partyName] ? [...updatedInvoicesByParty[partyName]] : [];
      partyInvoices.push(newInvoice);
      updatedInvoicesByParty[partyName] = partyInvoices.sort((a,b) => new Date(b.invoiceDate) - new Date(a.invoiceDate));
      toast({ title: "Invoice Created", description: `Invoice ${newInvoice.id} has been created.` });
    }
    
    setInvoicesByParty(updatedInvoicesByParty);
    localStorage.setItem("invoicesByParty", JSON.stringify(updatedInvoicesByParty));
    setIsCreateInvoiceDialogOpen(false);
  };

  const handleEditInvoice = (invoice) => {
    if (!canEdit) {
      toast({ title: "Permission Denied", description: "You do not have permission to edit invoices.", variant: "destructive" });
      return;
    }
    setEditingInvoice(invoice);
    setIsCreateInvoiceDialogOpen(true);
  };

  const handleDeleteInvoice = (invoice) => {
     if (!canDelete) {
      toast({ title: "Permission Denied", description: "You do not have permission to delete invoices.", variant: "destructive" });
      return;
    }
    setInvoiceToDelete(invoice);
    setIsDeleteDialogOpen(true);
  };

  const confirmDeleteInvoice = () => {
    if (!invoiceToDelete) return;

    let updatedInvoicesByParty = { ...invoicesByParty };
    const partyName = invoiceToDelete.customerName;

    updatedInvoicesByParty[partyName] = updatedInvoicesByParty[partyName]?.filter(inv => inv.id !== invoiceToDelete.id);
    if (updatedInvoicesByParty[partyName]?.length === 0) {
      delete updatedInvoicesByParty[partyName];
    }

    setInvoicesByParty(updatedInvoicesByParty);
    localStorage.setItem("invoicesByParty", JSON.stringify(updatedInvoicesByParty));
    toast({ title: "Invoice Deleted", description: `Invoice ${invoiceToDelete.id} has been deleted.` });
    
    setIsDeleteDialogOpen(false);
    setInvoiceToDelete(null);
  };
  
  const allInvoicesList = getAllInvoices();
  const filteredInvoices = allInvoicesList.filter(invoice =>
    invoice.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    invoice.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (invoice.vehicleNo && invoice.vehicleNo.toLowerCase().includes(searchQuery.toLowerCase()))
  ).sort((a,b) => new Date(b.invoiceDate) - new Date(a.invoiceDate));

  const handleViewInvoice = (invoice) => {
    setSelectedInvoice(invoice);
    setIsViewInvoiceDialogOpen(true);
  };

  return (
    <>
      <Header title="Invoicing" />
      <PageContainer>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
            <h1 className="text-3xl font-semibold text-gray-100">Manage Invoices</h1>
            {canEdit && (
              <Button onClick={() => { setEditingInvoice(null); setIsCreateInvoiceDialogOpen(true); }} className="bg-primary hover:bg-primary/80 text-white">
                <Plus className="h-5 w-5 mr-2" />
                Create Invoice
              </Button>
            )}
          </div>
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search by Customer, Invoice ID, or Vehicle No..."
                className="pl-10 py-3 text-base bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-400 focus:ring-primary focus:border-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {filteredInvoices.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredInvoices.map(invoice => (
                <InvoiceCard 
                  key={invoice.id} 
                  invoice={invoice} 
                  onViewInvoice={handleViewInvoice}
                  onEditInvoice={canEdit ? handleEditInvoice : undefined}
                  onDeleteInvoice={canDelete ? handleDeleteInvoice : undefined}
                  canEdit={canEdit}
                  canDelete={canDelete}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-slate-800 rounded-lg shadow-md">
              <FileText className="h-16 w-16 mx-auto text-gray-500 mb-6" />
              <h3 className="text-xl font-medium text-gray-200">No invoices found</h3>
              <p className="text-gray-400 mt-2">
                {searchQuery ? "Try a different search term." : (canEdit ? "Create your first invoice to get started." : "No invoices available to display.")}
              </p>
              {canEdit && !searchQuery && (
                <Button className="mt-6 bg-primary hover:bg-primary/80 text-white" onClick={() => { setEditingInvoice(null); setIsCreateInvoiceDialogOpen(true); }}>
                  <Plus className="h-5 w-5 mr-2" /> Create Invoice
                </Button>
              )}
            </div>
          )}
        </motion.div>

        <CreateInvoiceDialog
          isOpen={isCreateInvoiceDialogOpen}
          onOpenChange={(isOpen) => {
            setIsCreateInvoiceDialogOpen(isOpen);
            if (!isOpen) setEditingInvoice(null); 
          }}
          onCreateInvoice={handleCreateOrUpdateInvoiceSubmit}
          existingInvoiceData={editingInvoice}
        />

        <ViewInvoiceDialog
          isOpen={isViewInvoiceDialogOpen}
          onOpenChange={setIsViewInvoiceDialogOpen}
          selectedInvoice={selectedInvoice}
        />

        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent className="bg-slate-800 border-slate-700 text-gray-100">
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription className="text-gray-400">
                This action cannot be undone. This will permanently delete the invoice <span className="font-semibold">{invoiceToDelete?.id}</span> for <span className="font-semibold">{invoiceToDelete?.customerName}</span>.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="hover:bg-slate-700 border-slate-600">Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDeleteInvoice} className="bg-destructive hover:bg-destructive/80">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

      </PageContainer>
    </>
  );
};

export default InvoicingPage;

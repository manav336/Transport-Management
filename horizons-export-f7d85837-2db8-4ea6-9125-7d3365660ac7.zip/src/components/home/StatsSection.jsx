import React from "react";
import { motion } from "framer-motion";
import StatCard from "@/components/dashboard/StatCard";
import { Truck, AlertCircle, Calendar } from "lucide-react";

const StatsSection = ({ vehicles, tripsCount = 5 }) => {
  const stats = [
    { 
      title: "Total Vehicles", 
      value: vehicles.length, 
      icon: <Truck className="h-6 w-6 text-blue-600" />, 
      color: "bg-blue-100" 
    },
    { 
      title: "Active Vehicles", 
      value: vehicles.filter(v => v.status === "active").length, 
      trend: vehicles.length > 0 ? Math.round((vehicles.filter(v => v.status === "active").length / vehicles.length) * 10) - 5 : 0, 
      icon: <Truck className="h-6 w-6 text-green-600" />, 
      color: "bg-green-100" 
    },
    { 
      title: "In Maintenance", 
      value: vehicles.filter(v => v.status === "maintenance").length, 
      trend: vehicles.length > 0 ? Math.round((vehicles.filter(v => v.status === "maintenance").length / vehicles.length) * 5) - 2 : 0, 
      icon: <AlertCircle className="h-6 w-6 text-amber-600" />, 
      color: "bg-amber-100" 
    },
    { 
      title: "Scheduled Trips", 
      value: tripsCount, 
      icon: <Calendar className="h-6 w-6 text-purple-600" />, 
      color: "bg-purple-100" 
    }
  ];

  return (
    <div className="mb-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {stats.map((stat, index) => (
          <StatCard 
            key={index}
            title={stat.title}
            value={stat.value}
            trend={stat.trend}
            icon={stat.icon}
            color={stat.color}
          />
        ))}
      </motion.div>
    </div>
  );
};

export default StatsSection;
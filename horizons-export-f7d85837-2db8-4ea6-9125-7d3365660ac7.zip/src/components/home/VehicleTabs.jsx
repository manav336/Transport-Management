import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import VehicleCard from "@/components/vehicles/VehicleCard";
import { Plus, Search, Truck, AlertCircle } from "lucide-react";

const VehicleTabs = ({ vehicles, searchQuery, onSearchChange, onVehicleSelect, onAddVehicleClick }) => {
  const filteredVehicles = vehicles.filter(vehicle => 
    vehicle.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    vehicle.regNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderVehicleList = (vehicleList, statusType) => {
    if (vehicleList.length === 0) {
      let message = "No vehicles found";
      let subMessage = searchQuery ? "Try a different search term" : "Add your first vehicle to get started";
      let icon = <Truck className="h-8 w-8 text-muted-foreground" />;

      if (statusType === "active") {
        message = "No active vehicles";
        subMessage = "All your vehicles are currently inactive or in maintenance";
      } else if (statusType === "maintenance") {
        message = "No vehicles in maintenance";
        subMessage = "All your vehicles are currently active or inactive";
        icon = <AlertCircle className="h-8 w-8 text-muted-foreground" />;
      }

      return (
        <div className="col-span-full text-center py-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
            {icon}
          </div>
          <h3 className="text-lg font-medium">{message}</h3>
          <p className="text-muted-foreground mt-1">{subMessage}</p>
          {statusType === "all" && (
            <Button className="mt-4" onClick={onAddVehicleClick}>
              <Plus className="h-4 w-4 mr-2" />
              Add Vehicle
            </Button>
          )}
        </div>
      );
    }
    return vehicleList.map(vehicle => (
      <VehicleCard 
        key={vehicle.id} 
        vehicle={vehicle} 
        onSelect={onVehicleSelect}
      />
    ));
  };

  return (
    <Tabs defaultValue="all" className="w-full">
      <div className="flex justify-between items-center mb-4">
        <TabsList>
          <TabsTrigger value="all">All Vehicles</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
        </TabsList>
        
        <Button onClick={onAddVehicleClick}>
          <Plus className="h-4 w-4 mr-2" />
          Add Vehicle
        </Button>
      </div>
      
      <div className="mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search vehicles..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
      </div>

      <TabsContent value="all" className="mt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {renderVehicleList(filteredVehicles, "all")}
        </div>
      </TabsContent>
      
      <TabsContent value="active" className="mt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {renderVehicleList(filteredVehicles.filter(v => v.status === "active"), "active")}
        </div>
      </TabsContent>
      
      <TabsContent value="maintenance" className="mt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {renderVehicleList(filteredVehicles.filter(v => v.status === "maintenance"), "maintenance")}
        </div>
      </TabsContent>
    </Tabs>
  );
};

export default VehicleTabs;

import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Truck, MapPin, AlertCircle, CheckCircle } from "lucide-react";

const VehicleCard = ({ vehicle, onSelect }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case "active":
        return "text-green-500";
      case "maintenance":
        return "text-amber-500";
      case "inactive":
        return "text-red-500";
      default:
        return "text-gray-500";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case "maintenance":
        return <AlertCircle className="h-5 w-5 text-amber-500" />;
      case "inactive":
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
      className="w-full"
    >
      <Card className="card-hover overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-blue-500 to-indigo-600 relative">
          <div className="absolute inset-0 flex items-center justify-center">
            <Truck size={64} className="text-white" />
          </div>
        </div>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-3">
            <div>
              <h3 className="text-lg font-bold">{vehicle.name}</h3>
              <p className="text-sm text-muted-foreground">{vehicle.regNumber}</p>
            </div>
            <div className="flex items-center">
              {getStatusIcon(vehicle.status)}
              <span className={`ml-1 text-sm font-medium ${getStatusColor(vehicle.status)}`}>
                {vehicle.status.charAt(0).toUpperCase() + vehicle.status.slice(1)}
              </span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center text-sm">
              <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>{vehicle.location || "Unknown location"}</span>
            </div>
            <div className="flex items-center text-sm">
              <span className="font-medium mr-2">Fuel:</span>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full" 
                  style={{ width: `${vehicle.fuelLevel}%` }}
                ></div>
              </div>
              <span className="ml-2">{vehicle.fuelLevel}%</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onSelect(vehicle)}
          >
            Details
          </Button>
          <Button 
            variant="default" 
            size="sm"
            onClick={() => onSelect(vehicle)}
          >
            Assign Trip
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default VehicleCard;

import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Printer } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";

const ViewInvoiceDialog = ({ isOpen, onOpenChange, selectedInvoice }) => {
  const { toast } = useToast();

  const formatAmountWithSpaces = (amount) => {
    if (amount === null || amount === undefined) return "";
    const num = parseFloat(amount);
    if (isNaN(num)) return "";
    const [integerPart, decimalPart] = num.toFixed(2).split('.');
    const spacedInteger = integerPart.split('').join(' ');
    return `${spacedInteger}${decimalPart ? ` . ${decimalPart.split('').join(' ')}` : ''}`;
  };
  
  const getMonthName = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleString('default', { month: 'long' });
  };

  const handlePrintInvoice = () => {
    if (!selectedInvoice) return;

    const billerName = "DHARMENDRA KUMAR"; 
    const billerAddress = "House No.P-15, Pana Udyan, North west Delhi -110040";
    const billerPan = "KGTPK4092R";
    const companyNameForTitle = selectedInvoice.customerName || "Customer";

    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Invoice - '+selectedInvoice.id+'</title>');
    printWindow.document.write(`
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; color: #333; font-size: 12px; }
        .invoice-container { max-width: 800px; margin: auto; padding: 20px; border: 1px solid #ccc; }
        .header-section { margin-bottom: 15px; }
        .header-section table { width: 100%; }
        .header-section td { padding: 1px 0; }
        .header-left { text-align: left; }
        .header-right { text-align: right; }
        .biller-info-section { text-align: center; margin-bottom: 15px; }
        .biller-name { font-size: 1.1em; font-weight: bold; margin: 0; }
        .biller-address, .biller-pan { font-size: 0.9em; margin: 2px 0; }
        .items-table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 15px; }
        .items-table th, .items-table td { border: 1px solid #ccc; padding: 6px; text-align: left; }
        .items-table th { background-color: #f2f2f2; font-weight: bold; }
        .items-table td.money-column, .items-table th.money-column { text-align: right; }
        .total-section { text-align: right; margin-top: 15px; font-size: 1em; }
        .total-label { font-weight: normal; }
        .total-amount-spaced { font-weight: bold; letter-spacing: 1px; } /* Adjusted spacing */
        .for-company-name { text-align: right; margin-top: 40px; margin-bottom: 20px; font-weight: bold;}
        .signature-line { text-align: right; margin-top: 50px; }
        .signature-line span { border-top: 1px solid #333; padding-top: 5px; font-size: 0.9em; }
        hr.separator { border: 0; border-top: 1px dashed #ccc; margin: 10px 0; }
      </style>
    `);
    printWindow.document.write('</head><body>');
    printWindow.document.write('<div class="invoice-container">');

    printWindow.document.write('<div class="header-section">');
    printWindow.document.write('<table><tr>');
    printWindow.document.write('<td class="header-left"><strong>BILL NO:-</strong> '+selectedInvoice.id+'</td>');
    printWindow.document.write('<td class="header-right"><strong>DATE:-</strong> '+new Date(selectedInvoice.invoiceDate).toLocaleDateString('en-GB')+'</td>');
    printWindow.document.write('</tr><tr>');
    printWindow.document.write('<td class="header-left"><strong>Vehicle No:</strong> '+(selectedInvoice.vehicleNo || 'N/A')+'</td>');
    printWindow.document.write('<td class="header-right"><strong>BILL MONTH:</strong> '+getMonthName(selectedInvoice.invoiceDate).toUpperCase()+'</td>');
    printWindow.document.write('</tr></table>');
    printWindow.document.write('</div>');
    
    printWindow.document.write('<div class="biller-info-section">');
    printWindow.document.write('<div class="biller-name">'+billerName+'</div>');
    printWindow.document.write('<div class="biller-address">'+billerAddress+'</div>');
    printWindow.document.write('<div class="biller-pan"><strong>Pan No.</strong> '+billerPan+'</div>');
    printWindow.document.write('</div>');
    
    printWindow.document.write('<hr class="separator">');

    printWindow.document.write('<table class="items-table">');
    printWindow.document.write('<thead><tr><th>DATE</th><th>TO-FROM</th><th class="money-column">AMOUNT</th></tr></thead>');
    printWindow.document.write('<tbody>');
    let totalAmountForCalc = 0;
    selectedInvoice.items.forEach(item => {
      const itemAmount = (parseFloat(item.quantity) || 0) * (parseFloat(item.unitPrice) || 0);
      totalAmountForCalc += itemAmount;
      printWindow.document.write('<tr>');
      printWindow.document.write('<td>'+(item.itemDate ? new Date(item.itemDate).toLocaleDateString('en-GB') : new Date(selectedInvoice.invoiceDate).toLocaleDateString('en-GB'))+'</td>'); 
      printWindow.document.write('<td>'+item.description+'</td>');
      printWindow.document.write('<td class="money-column">'+itemAmount.toFixed(2)+'</td>');
      printWindow.document.write('</tr>');
    });
    printWindow.document.write('</tbody></table>');
    
    printWindow.document.write('<div class="total-section">');
    printWindow.document.write('<span class="total-label">T o t a l : &nbsp;&nbsp;</span>');
    printWindow.document.write('<span class="total-amount-spaced">'+formatAmountWithSpaces(totalAmountForCalc)+'</span>');
    printWindow.document.write('</div>');

    printWindow.document.write('<div class="for-company-name">For ' + billerName + '</div>');

    printWindow.document.write('<div class="signature-line"><span>Authorised Signatory</span></div>');

    printWindow.document.write('</div>'); 
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    
    setTimeout(() => { 
      printWindow.print();
      printWindow.close();
    }, 250);

    toast({ title: "Printing Invoice", description: `Preparing invoice ${selectedInvoice.id} for printing.` });
  };

  if (!selectedInvoice) return null;
  const totalAmount = selectedInvoice.items.reduce((sum, item) => sum + (parseFloat(item.quantity) || 0) * (parseFloat(item.unitPrice) || 0), 0);


  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Invoice Details: {selectedInvoice.id}</DialogTitle>
          <DialogDescription>
            Customer: {selectedInvoice.customerName}
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="max-h-[70vh] p-1">
          <div className="py-4 space-y-4 pr-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">BILL NO:</p>
                <p className="font-semibold">{selectedInvoice.id}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">DATE:</p>
                <p className="font-semibold">{new Date(selectedInvoice.invoiceDate).toLocaleDateString('en-GB')}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Vehicle No:</p>
                <p className="font-semibold">{selectedInvoice.vehicleNo || "N/A"}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">BILL MONTH:</p>
                <p className="font-semibold">{getMonthName(selectedInvoice.invoiceDate).toUpperCase()}</p>
              </div>
            </div>

            <Separator />

            <div className="text-center">
              <h4 className="font-bold text-lg">DHARMENDRA KUMAR</h4>
              <p className="text-sm">House No.P-15, Pana Udyan, North west Delhi -110040</p>
              <p className="text-sm">Pan No. KGTPK4092R</p>
            </div>
            
            <Separator />
            
            <div>
              <p className="text-sm text-muted-foreground">Bill To:</p>
              <p className="font-semibold">{selectedInvoice.customerName}</p>
              <p>{selectedInvoice.customerAddress}</p>
            </div>
            
            <Separator />
            <h4 className="font-semibold">Items:</h4>
            <div className="space-y-1">
              <div className="grid grid-cols-4 font-medium p-2 border-b">
                <span className="col-span-1">DATE</span>
                <span className="col-span-2">TO-FROM (Description)</span>
                <span className="text-right col-span-1">AMOUNT</span>
              </div>
              {selectedInvoice.items.map((item, index) => (
                <div key={index} className="grid grid-cols-4 items-center p-2 border-b last:border-b-0">
                  <span className="col-span-1 text-sm">{item.itemDate ? new Date(item.itemDate).toLocaleDateString('en-GB') : new Date(selectedInvoice.invoiceDate).toLocaleDateString('en-GB')}</span>
                  <span className="col-span-2 text-sm">{item.description} (Qty: {item.quantity}, Rate: {parseFloat(item.unitPrice || 0).toFixed(2)})</span>
                  <span className="text-right font-medium col-span-1">${((parseFloat(item.quantity) || 0) * (parseFloat(item.unitPrice) || 0)).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <Separator />
            <div className="flex justify-end items-center">
              <p className="text-lg"><span className="font-normal text-muted-foreground">T o t a l : &nbsp;&nbsp;</span> <span className="font-bold tracking-[1px]">{formatAmountWithSpaces(totalAmount)}</span></p>
            </div>
          </div>
        </ScrollArea>
        <DialogFooter>
          <Button variant="outline" onClick={handlePrintInvoice}>
            <Printer className="h-4 w-4 mr-2" /> Print / Download
          </Button>
          <DialogClose asChild>
            <Button>Close</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ViewInvoiceDialog;
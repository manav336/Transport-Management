import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Edit, Trash2 } from "lucide-react";

const InvoiceCard = ({ invoice, onViewInvoice, onEditInvoice, onDeleteInvoice, canEdit, canDelete }) => {
  const getStatusClass = (status) => {
    switch (status) {
      case "Paid":
        return "bg-green-500/20 text-green-400";
      case "Pending":
        return "bg-amber-500/20 text-amber-400";
      case "Overdue":
        return "bg-red-500/20 text-red-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };

  return (
    <Card className="card-hover bg-slate-800 border-slate-700 text-gray-100 shadow-lg hover:shadow-primary/30 transition-shadow duration-300">
      <CardHeader>
        <CardTitle className="flex justify-between items-center text-lg">
          {invoice.id}
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${getStatusClass(invoice.status)}`}>
            {invoice.status}
          </span>
        </CardTitle>
        <CardDescription className="text-gray-400">{invoice.customerName}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-1">
        <p className="text-sm text-gray-400">Vehicle No: <span className="text-gray-200">{invoice.vehicleNo || "N/A"}</span></p>
        <p className="text-sm text-gray-400">Date: <span className="text-gray-200">{new Date(invoice.invoiceDate).toLocaleDateString()}</span></p>
        <p className="text-sm text-gray-400">Due Date: <span className="text-gray-200">{new Date(invoice.dueDate).toLocaleDateString()}</span></p>
        <p className="text-xl font-semibold mt-3 text-primary">${invoice.amount.toFixed(2)}</p>
      </CardContent>
      <CardFooter className="flex justify-end space-x-2 pt-4">
        <Button variant="outline" size="sm" onClick={() => onViewInvoice(invoice)} className="border-slate-600 hover:bg-slate-700 hover:text-primary">
          <Eye className="h-4 w-4 mr-1" /> View
        </Button>
        {canEdit && onEditInvoice && (
          <Button variant="outline" size="sm" onClick={() => onEditInvoice(invoice)} className="border-slate-600 hover:bg-slate-700 hover:text-amber-400">
            <Edit className="h-4 w-4 mr-1" /> Edit
          </Button>
        )}
        {canDelete && onDeleteInvoice && (
           <Button variant="outline" size="sm" onClick={() => onDeleteInvoice(invoice)} className="border-red-500/50 text-red-400 hover:bg-red-500/20 hover:text-red-300">
            <Trash2 className="h-4 w-4 mr-1" /> Delete
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default InvoiceCard;
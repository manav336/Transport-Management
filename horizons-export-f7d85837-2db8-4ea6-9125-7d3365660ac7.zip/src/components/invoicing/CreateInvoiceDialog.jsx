import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

const CreateInvoiceDialog = ({ isOpen, onOpenChange, onCreateInvoice, existingInvoiceData }) => {
  const initialItem = {
    itemDate: new Date().toISOString().split('T')[0],
    description: "",
    quantity: 1,
    unitPrice: 0,
  };
  const getInitialInvoiceData = () => ({
    customerName: "",
    customerAddress: "",
    vehicleNo: "",
    invoiceDate: new Date().toISOString().split('T')[0],
    dueDate: "",
    items: [initialItem],
    status: "Pending",
    ...existingInvoiceData
  });

  const [newInvoiceData, setNewInvoiceData] = useState(getInitialInvoiceData());

  useEffect(() => {
    setNewInvoiceData(getInitialInvoiceData());
  }, [existingInvoiceData, isOpen]);


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewInvoiceData(prev => ({ ...prev, [name]: value }));
  };

  const handleItemChange = (index, e) => {
    const { name, value } = e.target;
    const items = [...newInvoiceData.items];
    const numericValue = name === "quantity" || name === "unitPrice" ? parseFloat(value) : value;
    items[index][name] = (name === "quantity" || name === "unitPrice") ? (isNaN(numericValue) ? "" : numericValue) : value;
    setNewInvoiceData(prev => ({ ...prev, items }));
  };

  const addItem = () => {
    setNewInvoiceData(prev => ({
      ...prev,
      items: [...prev.items, { ...initialItem, itemDate: new Date().toISOString().split('T')[0] }],
    }));
  };

  const removeItem = (index) => {
    const items = [...newInvoiceData.items];
    if (items.length > 1) {
      items.splice(index, 1);
      setNewInvoiceData(prev => ({ ...prev, items }));
    }
  };

  const calculateTotalAmount = (items) => {
    return items.reduce((total, item) => {
      const quantity = parseFloat(item.quantity) || 0;
      const unitPrice = parseFloat(item.unitPrice) || 0;
      return total + (quantity * unitPrice);
    }, 0);
  };

  const handleSubmit = () => {
    onCreateInvoice(newInvoiceData);
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl bg-slate-800 border-slate-700 text-gray-100">
        <DialogHeader>
          <DialogTitle className="text-2xl">{existingInvoiceData ? "Edit Invoice" : "Create New Invoice"}</DialogTitle>
          <DialogDescription className="text-gray-400">
            {existingInvoiceData ? "Update the invoice details below." : "Fill in the details to create a new invoice. Biller details are fixed."}
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="max-h-[70vh] p-1 pr-2">
          <div className="grid gap-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="customerName" className="text-gray-300">Customer Name (Party)</Label>
                <Input id="customerName" name="customerName" value={newInvoiceData.customerName} onChange={handleInputChange} className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
              </div>
              <div>
                <Label htmlFor="customerAddress" className="text-gray-300">Customer Address</Label>
                <Input id="customerAddress" name="customerAddress" value={newInvoiceData.customerAddress} onChange={handleInputChange} className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="vehicleNo" className="text-gray-300">Vehicle No.</Label>
                <Input id="vehicleNo" name="vehicleNo" value={newInvoiceData.vehicleNo} onChange={handleInputChange} className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
              </div>
              <div>
                <Label htmlFor="invoiceDate" className="text-gray-300">Invoice Date (Sets Bill Month)</Label>
                <Input id="invoiceDate" name="invoiceDate" type="date" value={newInvoiceData.invoiceDate} onChange={handleInputChange} className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
              </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="dueDate" className="text-gray-300">Due Date</Label>
                    <Input id="dueDate" name="dueDate" type="date" value={newInvoiceData.dueDate} onChange={handleInputChange} className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
                </div>
                {existingInvoiceData && (
                  <div>
                    <Label htmlFor="status" className="text-gray-300">Status</Label>
                    <select 
                      id="status" 
                      name="status" 
                      value={newInvoiceData.status} 
                      onChange={handleInputChange}
                      className="flex h-10 w-full rounded-md border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-gray-100 ring-offset-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                    >
                      <option value="Pending">Pending</option>
                      <option value="Paid">Paid</option>
                      <option value="Overdue">Overdue</option>
                    </select>
                  </div>
                )}
            </div>

            <Separator className="my-4 bg-slate-700" />
            <h4 className="font-medium col-span-full text-lg text-gray-200">Invoice Items</h4>
            {newInvoiceData.items.map((item, index) => (
              <div key={index} className="grid grid-cols-1 sm:grid-cols-12 gap-3 border border-slate-700 p-4 rounded-lg bg-slate-700/30 items-end">
                <div className="sm:col-span-3">
                  <Label htmlFor={`itemDate-${index}`} className="text-gray-300">Date</Label>
                  <Input id={`itemDate-${index}`} type="date" name="itemDate" value={item.itemDate} onChange={(e) => handleItemChange(index, e)} className="bg-slate-600 border-slate-500 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
                </div>
                <div className="sm:col-span-4">
                  <Label htmlFor={`description-${index}`} className="text-gray-300">To-From (Description)</Label>
                  <Input id={`description-${index}`} placeholder="e.g., Delhi to Mumbai" name="description" value={item.description} onChange={(e) => handleItemChange(index, e)} className="bg-slate-600 border-slate-500 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor={`quantity-${index}`} className="text-gray-300">Qty</Label>
                  <Input id={`quantity-${index}`} type="number" placeholder="Qty" name="quantity" value={item.quantity} onChange={(e) => handleItemChange(index, e)} min="0" className="bg-slate-600 border-slate-500 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor={`unitPrice-${index}`} className="text-gray-300">Rate</Label>
                  <Input id={`unitPrice-${index}`} type="number" placeholder="Rate" name="unitPrice" value={item.unitPrice} onChange={(e) => handleItemChange(index, e)} min="0" step="0.01" className="bg-slate-600 border-slate-500 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
                </div>
                <div className="sm:col-span-1 flex items-end">
                  {newInvoiceData.items.length > 1 && (
                    <Button variant="ghost" size="sm" onClick={() => removeItem(index)} className="text-red-400 hover:bg-red-500/20 w-full">X</Button>
                  )}
                </div>
              </div>
            ))}
            <Button variant="outline" onClick={addItem} className="mt-2 w-full sm:w-auto border-primary text-primary hover:bg-primary/10 hover:text-primary">Add Item</Button>
            <Separator className="my-4 bg-slate-700" />
            <div className="text-right font-bold text-xl text-gray-100">
              Total Amount: ${calculateTotalAmount(newInvoiceData.items).toFixed(2)}
            </div>
          </div>
        </ScrollArea>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline" className="hover:bg-slate-700 border-slate-600">Cancel</Button>
          </DialogClose>
          <Button onClick={handleSubmit} className="bg-primary hover:bg-primary/90 text-white">{existingInvoiceData ? "Save Changes" : "Create Invoice"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CreateInvoiceDialog;
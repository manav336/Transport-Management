import React from "react";
import { NavLink } from "react-router-dom";
import { motion } from "framer-motion";
import { Truck, Users, BarChart, Calendar, Settings, FileText } from "lucide-react";

const MobileNavbar = () => {
  const navItems = [
    { to: "/", icon: <Truck size={24} />, label: "Vehicles" },
    { to: "/drivers", icon: <Users size={24} />, label: "Drivers" },
    { to: "/trips", icon: <Calendar size={24} />, label: "Trips" },
    { to: "/invoicing", icon: <FileText size={24} />, label: "Invoicing" },
    { to: "/reports", icon: <BarChart size={24} />, label: "Reports" },
    { to: "/settings", icon: <Settings size={24} />, label: "Settings" },
  ];

  return (
    <motion.nav
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-2 py-2 z-50 md:hidden"
    >
      <div className="flex justify-around items-center">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `mobile-nav-item ${isActive ? "active" : ""}`
            }
          >
            <div className="flex flex-col items-center">
              {item.icon}
              <span className="text-xs mt-1">{item.label}</span>
            </div>
          </NavLink>
        ))}
      </div>
    </motion.nav>
  );
};

export default MobileNavbar;
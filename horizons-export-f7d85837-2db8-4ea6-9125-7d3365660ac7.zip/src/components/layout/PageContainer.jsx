
import React from "react";
import { motion } from "framer-motion";

const PageContainer = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="flex-1 p-4 pb-20 md:pb-4 overflow-y-auto"
    >
      {children}
    </motion.div>
  );
};

export default PageContainer;

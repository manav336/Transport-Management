
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const StatCard = ({ icon, title, value, trend, color }) => {
  const isPositive = trend > 0;
  
  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
      className="w-full"
    >
      <Card className="card-hover overflow-hidden">
        <CardContent className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
              <h3 className="text-2xl font-bold">{value}</h3>
              
              {trend !== undefined && (
                <div className={`flex items-center mt-2 text-sm ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                  <span>{isPositive ? '↑' : '↓'} {Math.abs(trend)}%</span>
                  <span className="ml-1 text-muted-foreground">vs last month</span>
                </div>
              )}
            </div>
            
            <div className={`p-3 rounded-full ${color || 'bg-blue-100'}`}>
              {icon}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default StatCard;

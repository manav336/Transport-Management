import React from "react";
import { CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";

const CompanySettings = () => {
  const { toast } = useToast();

  const handleSaveSettings = (e) => {
    e.preventDefault();
    toast({
      title: "Company Settings Saved",
      description: "Company information has been successfully updated.",
      className: "bg-slate-700 text-white border-slate-600",
    });
  };

  return (
    <form onSubmit={handleSaveSettings}>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="company-name" className="text-gray-300">Company Name</Label>
          <Input id="company-name" defaultValue="Transport Solutions Inc." className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="business-address" className="text-gray-300">Business Address</Label>
          <Input id="business-address" defaultValue="123 Logistics Way, Transport City" className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tax-id" className="text-gray-300">Tax ID / Business Number</Label>
          <Input id="tax-id" defaultValue="TX-12345678" className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        
        <Separator className="my-4 bg-slate-700" />
        
        <div className="space-y-2">
          <Label htmlFor="business-type" className="text-gray-300">Business Type</Label>
          <select 
            id="business-type" 
            className="flex h-10 w-full rounded-md border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-gray-100 ring-offset-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          >
            <option value="logistics">Logistics</option>
            <option value="freight">Freight</option>
            <option value="delivery">Delivery Service</option>
            <option value="other">Other</option>
          </select>
        </div>
      </CardContent>
      <CardFooter>
        <Button type="submit" className="bg-primary hover:bg-primary/90 text-white">Save Changes</Button>
      </CardFooter>
    </form>
  );
};

export default CompanySettings;

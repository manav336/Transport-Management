import React from "react";
import { CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const HelpItem = ({ title, description, buttonText, onButtonClick }) => (
  <div className="bg-slate-700/50 p-6 rounded-lg shadow">
    <h4 className="text-md font-semibold text-gray-100 mb-2">{title}</h4>
    <p className="text-sm text-gray-400 mb-4">
      {description}
    </p>
    <Button variant="outline" size="sm" onClick={onButtonClick} className="border-primary text-primary hover:bg-primary/10 hover:text-primary">
      {buttonText}
    </Button>
  </div>
);

const HelpSupport = () => {
  const openLink = (url) => window.open(url, '_blank');

  return (
    <CardContent>
      <div className="space-y-6">
        <HelpItem 
          title="Documentation"
          description="Access comprehensive guides and documentation to help you use the system effectively."
          buttonText="View Documentation"
          onButtonClick={() => openLink("#")}
        />
        <HelpItem 
          title="Contact Support"
          description="Need help? Our support team is available 24/7 to assist you."
          buttonText="Contact Support"
          onButtonClick={() => openLink("mailto:support@example.com")}
        />
        <HelpItem 
          title="Frequently Asked Questions"
          description="Find answers to common questions about using the transport management system."
          buttonText="View FAQs"
          onButtonClick={() => openLink("#")}
        />
      </div>
    </CardContent>
  );
};

export default HelpSupport;

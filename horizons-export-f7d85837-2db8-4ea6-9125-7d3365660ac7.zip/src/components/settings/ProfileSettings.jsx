import React from "react";
import { CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/AuthContext";

const ProfileSettings = () => {
  const { toast } = useToast();
  const { user } = useAuth();

  const handleSaveSettings = (e) => {
    e.preventDefault();
    toast({
      title: "Profile Settings Saved",
      description: "Your profile information has been successfully updated.",
      className: "bg-slate-700 text-white border-slate-600",
    });
  };

  return (
    <form onSubmit={handleSaveSettings}>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-gray-300">Full Name</Label>
          <Input id="name" defaultValue={user?.name || "User Name"} className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email" className="text-gray-300">Email Address</Label>
          <Input id="email" type="email" defaultValue={user?.id ? `${user.id}@example.com` : "user@example.com"} className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone" className="text-gray-300">Phone Number</Label>
          <Input id="phone" defaultValue="+1 234-567-8901" className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        
        <Separator className="my-4 bg-slate-700" />
        
        <div className="space-y-2">
          <Label htmlFor="language" className="text-gray-300">Preferred Language</Label>
          <select 
            id="language" 
            className="flex h-10 w-full rounded-md border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-gray-100 ring-offset-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          >
            <option value="en">English</option>
            <option value="es">Spanish</option>
            <option value="fr">French</option>
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="timezone" className="text-gray-300">Timezone</Label>
          <select 
            id="timezone" 
            className="flex h-10 w-full rounded-md border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-gray-100 ring-offset-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          >
            <option value="utc-8">Pacific Time (UTC-8)</option>
            <option value="utc-5">Eastern Time (UTC-5)</option>
            <option value="utc+0">UTC</option>
            <option value="utc+1">Central European Time (UTC+1)</option>
          </select>
        </div>
      </CardContent>
      <CardFooter>
        <Button type="submit" className="bg-primary hover:bg-primary/90 text-white">Save Changes</Button>
      </CardFooter>
    </form>
  );
};

export default ProfileSettings;

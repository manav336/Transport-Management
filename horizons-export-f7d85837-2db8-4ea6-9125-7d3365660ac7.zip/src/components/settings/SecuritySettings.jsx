import React from "react";
import { CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";

const SecuritySettings = () => {
  const { toast } = useToast();

  const handleSaveSettings = (e) => {
    e.preventDefault();
    toast({
      title: "Security Settings Updated",
      description: "Your password has been (simulated) updated.",
      className: "bg-slate-700 text-white border-slate-600",
    });
  };
  
  const handleEnable2FA = () => {
     toast({
      title: "Two-Factor Authentication",
      description: "2FA setup process would start here (simulated).",
      className: "bg-slate-700 text-white border-slate-600",
    });
  };

  return (
    <form onSubmit={handleSaveSettings}>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="current-password" className="text-gray-300">Current Password</Label>
          <Input id="current-password" type="password" className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="new-password" className="text-gray-300">New Password</Label>
          <Input id="new-password" type="password" className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm-password" className="text-gray-300">Confirm New Password</Label>
          <Input id="confirm-password" type="password" className="bg-slate-700 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-primary focus:border-primary" />
        </div>
        
        <Separator className="my-4 bg-slate-700" />
        
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-medium text-gray-200">Two-Factor Authentication</h4>
            <p className="text-sm text-gray-400">Add an extra layer of security to your account</p>
          </div>
          <Button variant="outline" size="sm" type="button" onClick={handleEnable2FA} className="border-primary text-primary hover:bg-primary/10 hover:text-primary">Enable</Button>
        </div>
      </CardContent>
      <CardFooter>
        <Button type="submit" className="bg-primary hover:bg-primary/90 text-white">Update Password</Button>
      </CardFooter>
    </form>
  );
};

export default SecuritySettings;

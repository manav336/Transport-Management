import React from "react";
import { CardContent, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/components/ui/use-toast";

const NotificationOption = ({ id, title, description, defaultEmailChecked = true, defaultPushChecked = true }) => (
  <>
    <div className="flex items-center justify-between">
      <div>
        <h4 className="text-sm font-medium text-gray-200">{title}</h4>
        <p className="text-sm text-gray-400">{description}</p>
      </div>
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Checkbox id={`${id}-email`} defaultChecked={defaultEmailChecked} className="border-slate-500 data-[state=checked]:bg-primary data-[state=checked]:border-primary" />
          <Label htmlFor={`${id}-email`} className="text-xs text-gray-300">Email</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id={`${id}-push`} defaultChecked={defaultPushChecked} className="border-slate-500 data-[state=checked]:bg-primary data-[state=checked]:border-primary" />
          <Label htmlFor={`${id}-push`} className="text-xs text-gray-300">Push</Label>
        </div>
      </div>
    </div>
    <Separator className="bg-slate-700" />
  </>
);


const NotificationSettings = () => {
  const { toast } = useToast();

  const handleSaveSettings = (e) => {
    e.preventDefault();
    toast({
      title: "Notification Preferences Saved",
      description: "Your notification settings have been updated.",
      className: "bg-slate-700 text-white border-slate-600",
    });
  };

  return (
    <form onSubmit={handleSaveSettings}>
      <CardContent>
        <div className="space-y-6">
          <NotificationOption 
            id="trip-updates"
            title="Trip Updates"
            description="Receive notifications about trip status changes"
          />
          <NotificationOption 
            id="maintenance-alerts"
            title="Maintenance Alerts"
            description="Receive notifications about vehicle maintenance"
          />
          <NotificationOption 
            id="driver-updates"
            title="Driver Updates"
            description="Receive notifications about driver status changes"
          />
           <NotificationOption 
            id="invoice-updates"
            title="Invoice Updates"
            description="Get notified for new invoices or payment reminders"
            defaultPushChecked={false}
          />
        </div>
      </CardContent>
      <CardFooter>
        <Button type="submit" className="bg-primary hover:bg-primary/90 text-white">Save Preferences</Button>
      </CardFooter>
    </form>
  );
};

export default NotificationSettings;

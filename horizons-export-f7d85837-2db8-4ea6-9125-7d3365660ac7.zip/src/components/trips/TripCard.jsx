
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Clock, Truck, User } from "lucide-react";

const TripCard = ({ trip, onSelect }) => {
  const getStatusBadge = (status) => {
    const statusStyles = {
      scheduled: "bg-blue-100 text-blue-800",
      inProgress: "bg-amber-100 text-amber-800",
      completed: "bg-green-100 text-green-800",
      cancelled: "bg-red-100 text-red-800"
    };
    
    return (
      <div className={`px-2 py-1 rounded-full text-xs font-medium ${statusStyles[status] || "bg-gray-100"}`}>
        {status.charAt(0).toUpperCase() + status.slice(1).replace(/([A-Z])/g, ' $1')}
      </div>
    );
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
      className="w-full"
    >
      <Card className="card-hover overflow-hidden">
        <div className="h-2 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-3">
            <h3 className="text-lg font-bold">{trip.title}</h3>
            {getStatusBadge(trip.status)}
          </div>
          
          <div className="space-y-3">
            <div className="flex items-start">
              <MapPin className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
              <div>
                <div className="text-sm font-medium">From: {trip.origin}</div>
                <div className="text-sm font-medium">To: {trip.destination}</div>
              </div>
            </div>
            
            <div className="flex items-center text-sm">
              <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>{trip.date}</span>
            </div>
            
            <div className="flex items-center text-sm">
              <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>{trip.departureTime} - {trip.estimatedArrival}</span>
            </div>
            
            <div className="flex justify-between">
              <div className="flex items-center text-sm">
                <Truck className="h-4 w-4 mr-2 text-muted-foreground" />
                <span>{trip.vehicle}</span>
              </div>
              
              <div className="flex items-center text-sm">
                <User className="h-4 w-4 mr-2 text-muted-foreground" />
                <span>{trip.driver}</span>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onSelect(trip)}
          >
            Details
          </Button>
          <Button 
            variant="default" 
            size="sm"
            onClick={() => onSelect(trip)}
          >
            {trip.status === "completed" ? "View Report" : "Update Status"}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default TripCard;

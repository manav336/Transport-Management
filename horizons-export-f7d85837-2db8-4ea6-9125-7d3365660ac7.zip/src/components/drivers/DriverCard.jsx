
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Phone, Calendar, MapPin } from "lucide-react";

const DriverCard = ({ driver, onSelect }) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
      className="w-full"
    >
      <Card className="card-hover overflow-hidden">
        <CardContent className="p-6 pt-6">
          <div className="flex flex-col items-center mb-4">
            <Avatar className="h-20 w-20 mb-3">
              <AvatarImage src={driver.avatar} />
              <AvatarFallback className="text-lg bg-primary text-white">
                {driver.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <h3 className="text-lg font-bold text-center">{driver.name}</h3>
            <p className="text-sm text-muted-foreground">{driver.licenseNumber}</p>
            
            <div className={`mt-2 px-2 py-1 rounded-full text-xs font-medium ${
              driver.status === "available" 
                ? "bg-green-100 text-green-800" 
                : "bg-amber-100 text-amber-800"
            }`}>
              {driver.status.charAt(0).toUpperCase() + driver.status.slice(1)}
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center text-sm">
              <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>{driver.phone}</span>
            </div>
            <div className="flex items-center text-sm">
              <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>Joined {driver.joinDate}</span>
            </div>
            {driver.currentLocation && (
              <div className="flex items-center text-sm">
                <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                <span>{driver.currentLocation}</span>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onSelect(driver)}
          >
            View Profile
          </Button>
          <Button 
            variant="default" 
            size="sm"
            onClick={() => onSelect(driver)}
          >
            Assign Trip
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default DriverCard;
